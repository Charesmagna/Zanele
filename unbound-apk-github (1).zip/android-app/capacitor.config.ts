import { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.unbound.muse',
  appName: 'UNBOUND Muse',
  webDir: 'www',
  backgroundColor: '#0b0b0e',
  android: { allowMixedContent: true }
};
export default config;
