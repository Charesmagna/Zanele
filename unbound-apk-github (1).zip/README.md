# UNBOUND Muse — GitHub to APK

## What is here
- `perchance-web/` — the generator source (main.pjs + index.html). Edit here, then paste back into the Perchance editor and Save.
- `android-app/www/` — the Android shell. It loads your published page at https://perchance.org/african-cultural-ai full-screen.
- `.github/workflows/build-apk.yml` — GitHub builds the APK for you. No Android Studio needed.

## Steps (phone-friendly)
1. Create a free GitHub account, make a new repository (any name).
2. Upload ALL these files to it (Add file > Upload files). Keep the folders as they are.
3. Open the repo > Actions tab > enable workflows if asked.
4. Tap the `Build APK` workflow > Run workflow (or just push any tiny edit).
5. Wait 5-10 minutes > open the finished run > download `unbound-muse-apk`.
6. On your Android: open the APK file to install (allow Install unknown apps for your browser/files app once).

## Change the app URL
If you rename the generator, edit `android-app/www/index.html` and replace https://perchance.org/african-cultural-ai with your new page URL, then re-run the workflow.

## Notes
- The APK needs internet: it shows your live Perchance page.
- Debug APK installs fine for personal use. For Play Store you need a signed release build (advanced).
- Never commit API keys. Video keys stay in the app's browser storage only.

## In-app updates (shell only)
Reminder: Perchance content updates are INSTANT — every Save shows in the installed app on next open. No update needed.

The pop-up Update button is only for shell changes (the wrapper itself):
1. In `android-app/www/index.html`, replace USER/REPO in UPDATE_CHECK_URL and UPDATE_DOWNLOAD_URL with your GitHub name and repo.
2. Bump `VERSION` there AND in `android-app/www/version.json` (e.g. 1.0.0 -> 1.1.0).
3. Push, let the workflow build, then attach the APK to a GitHub Release named `app.apk` (Releases > Draft new release > upload file, name it exactly app.apk).
4. Installed apps will pop the Update button on next launch. The button downloads the new APK; open it to install over the old one.
